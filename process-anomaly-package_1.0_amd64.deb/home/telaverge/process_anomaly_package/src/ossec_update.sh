#!/bin/bash

sudo systemctl restart wazuh-agent

sudo pip3 install -r /home/telaverge/process_anomaly_package/src/requirements.txt
